Hi. Thanks for downloading my minimal obsidian vault + settings :)

This file will explain how to actually set up and use this vault and settings.

##### **SETUP STEPS:**

[1.] Open to Obsidian.

[2.] In the bottom left you should see your current vault (if not, make sure your toolbar is open with the button top left), left click on your current vault and then click on "manage vaults".

[3.] Now, click "open folder as vault".

[4.] Locate this folder (Minimal Obsidian Vault + Settings) and click it to open it.

[5.] Your done with the setup!

##### **HOTKEYS/KEYBINDS:**

insert template: alt+t
new note: ctrl+n
close current tab: ctrl+w
close current window: ctrl+shift+w
follow the link under your cursor: alt+enter
open graph view: ctrl+g

for other hotkeys/keybinds go to: settings>hotkeys

##### **PLUGINS:**

These are the core plugins that are activated with my settings.

Backlinks
Bookmarks
Command palette
Daily notes
File recovery
Note composer
Page preview
Quick switcher
Sync
Templates
Files
Graph view
Outgoing links
Outline
Quick switcher
Search
Tags view
Unique note creator
Word count

(you can go into settings>core plugins to see what these do, change their settings or disable them)

##### **THEMES:**

These are the community themes I have installed.

Minimal
Obsidian gruvbox
Obsidian nord

##### **MARKDOWN**

Obsidian uses a markup language called markdown to style and format text. Here is an overview of how to use it.

Headers:
# H1 - Title
## H2 - Subtitle
### H3 - Section
#### H4 - Subsection
##### H5 - Smaller
###### H6 - Smallest

Text styling:
*Italic* or _Italic_  
**Bold** or __Bold__  
***Bold + Italic***  
~~Strikethrough~~

Links:
[A link to my website](https://harrisons-code.github.io/harrisons_website_new/index.html)

Images:
![The Great Wave Off Kanagawa](https://harrisons-code.github.io/harrisons_website_new/the_great_wave.png)

Unordered lists:
- Item A
- Item B
  - Subitem B.1
  - Subitem B.2
* Item C

Ordered Lists:
1. First
2. Second
3. Third
   4. Nested

Blockquotes:
> This is a blockquote.  
> It can span multiple lines.

Horizontal rules:

---

Tables:

| A   | B   | C   |
| --- | --- | --- |
| 1   | Y   | Y   |
| 2   | Y   | N   |
| 3   | N   | Y   |
| 4   | N   | N   |

Task lists:
- [x] read list item
- [ ] read list item again
- [ ] read list item one more time

Use a backslash `\` to escape special characters:
\*this text will appear with asterisks\*

---

Enjoy :) - *Harrison*