| Status                | Name         | Author         | Genre             | Rating     | Pages | Start Date | Finish Date | Amount Per Day | Times Read |
| --------------------- | ------------ | -------------- | ----------------- | ---------- | ----- | ---------- | ----------- | -------------- | ---------- |
| Read                  | Example Book | Example Author | [[example-genre]] | ⭐️⭐️⭐️⭐️⭐️ | XXX   | XX.XX.XX   | XX.XX.XX    | X minutes      | X          |
| **Currently reading** | Example Book | Example Author | [[example-genre]] | ⭐️⭐️⭐️⭐️⭐️ | XXX   | XX.XX.XX   | XX.XX.XX    | X minutes      | X          |
| Want to read          | Example Book | Example Author | [[example-genre]] | ⭐️⭐️⭐️⭐️⭐️ | XXX   | XX.XX.XX   | XX.XX.XX    | X minutes      | X          |
