
tags: [[books]]
start date: XX.XX.XX
end date: XX.XX.XX
author:
genre:
rating: ?/5
# {{Title}}

**XX.XX.XX - Quotes & Notes**



#references

